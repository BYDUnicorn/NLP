from flask import Flask, render_template, request, jsonify
from joblib import load
import re

app = Flask(__name__)

# Load model and vectorizer
classifier_model = load("../models/svm_classifier_model.joblib")
vectorizer = load("../models/vectorizer.joblib")

def preprocess_text(text):
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    text = text.lower()
    return text

def tokenize_text(text):
    words = text.split()
    return words

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/classify", methods=["POST"])
def classify():
    article_text = request.json["articleText"]
    preprocessed_text = preprocess_text(article_text)
    X = vectorizer.transform([preprocessed_text])

    predicted_category = classifier_model.predict(X)[0]
    confidence = classifier_model.decision_function(X)[0, classifier_model.classes_.tolist().index(predicted_category)]

    # Return results
    return jsonify({"category": predicted_category, "confidence": confidence})

if __name__ == "__main__":
    app.run(debug=True)
